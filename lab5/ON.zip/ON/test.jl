#Monika Tworek
#229776

push!(LOAD_PATH, "C:\\Users\\Monika\\Desktop\\ON")
using MyModule

function test1()
    flaga = true
    A, n, l = loadMatrix()
    b = loadVector()
    x = ones(n)
    A1, b1, err = Gauss(A, b, false, l, n)
    if (err == 1)
        println("Blad")
        flaga = false
    else
        x1 = ObliczGaussa(A1, b1, n, l)
        err1 = 0.0
        err1+=norm(x1 -x)/norm(x)
        println(err1)
    end
    A, n, l = loadMatrix()
    b = loadVector()
    A2, b2, err = Gauss(A, b, true, l, n)
    if (err == 1)
        println("Blad")
        flaga = false
    else
        x2 = ObliczGaussa(A2, b2, n, l)
        err2 = 0.0
        err2+=norm(x2 -x)/norm(x)
        println(err2)
    end
    if (flaga == true)
        writeX(x1, x2, n)
    end
    println("Done")
end

function test1prim()
    A, b,  n, l = genB()
    x = ones(n)
    A1, b1, err = Gauss(A, b, true, l, n)
    x1 = ObliczGaussa(A1, b1, n, l)
    err1 = 0.0
    err1+=norm(x1 -x)/norm(x)
    println(err1)
    A1, b1, err = Gauss(A, b, false, l, n)
    x2 = ObliczGaussa(A1, b1, n, l)
    err2 = 0.0
    err2+=norm(x2 -x)/norm(x)
    println(err2)
    writeX(x1, x2, n)
    println("Done")
end

function test2()
    A, n, l = loadMatrix()
    A1, err = rozkladLU(A, true, n, l)
    println(A1)

    A2, err = rozkladLU(A, false, n, l)
    println(A2)
end


function testPiotrka()
    A=spzeros(3,3)
    A[1,1]=2
    A[1,2]=-1
    A[1,3]=-2
    A[2,1]=-4
    A[2,2]=6
    A[2,3]=3
    A[3,1]=-4
    A[3,2]=-2
    A[3,3]=8

    A, err = rozkladLU(A, false, 3, 3)
    println(A)
end

function test3()
    A, n, l = loadMatrix()
    b = loadVector()
    x = ones(n)
    A1, b1, err = rozkladLU(A, b, true, l, n)
    x1 = ObliczLU(A1, b1, n, l)
    err1 = 0.0
    err1+=norm(x1 -x)/norm(x)
    # println(err1)
    println(x1)
    A1, b1, err = rozkladLU(A, b, false, l, n)
    x2 = ObliczLU(A1, b1, n, l)
    err2 = 0.0
    err2+=norm(x2 -x)/norm(x)
    # println(err2)
    println(x2)
end

function testON()
    A, n, l = loadMatrix()
    b = loadVector()
    x = ones(n)
    A1, b1, err = Gauss(A, b, true, l, n)
    if (err == 1)
        println("Blad")
    else
        x1 = ObliczGaussa(A1, b1, n, l)
        err1 = 0.0
        err1+=norm(x1-x)/norm(x)
        println(err1)
    end
end

testON()
